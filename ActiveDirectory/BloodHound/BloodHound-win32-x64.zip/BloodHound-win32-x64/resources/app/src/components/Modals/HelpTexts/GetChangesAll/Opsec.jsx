const Opsec = () => {
    let text = `For detailed information on detection of dcsync as well as opsec considerations, see the adsecurity post in the references tab.`;
    return { __html: text };
};

export default Opsec;
