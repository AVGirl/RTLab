const References = () => {
    let text = `<a href="https://blog.netspi.com/attacking-azure-cloud-shell/ ">https://blog.netspi.com/attacking-azure-cloud-shell/</a>`;
    return { __html: text };
};

export default References;
