const Opsec = () => {
    let text = `This depends on which abuse you perform, but in general Azure will create a log for each abuse action.`;
    return { __html: text };
};

export default Opsec;
