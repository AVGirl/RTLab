const References = () => {
    let text = `<a href='https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/'>https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/</a>`;
    return { __html: text };
};

export default References;
