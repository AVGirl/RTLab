const References = () => {
    let text = `<a href="https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/ ">https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/ </a>
    <a href="https://blog.netspi.com/azure-automation-accounts-key-stores/">https://blog.netspi.com/azure-automation-accounts-key-stores/</a> 
    <a href="https://blog.netspi.com/get-azurepasswords/">https://blog.netspi.com/get-azurepasswords/</a> 
    <a href="https://blog.netspi.com/attacking-azure-cloud-shell/">https://blog.netspi.com/attacking-azure-cloud-shell/</a> `;
    return { __html: text };
};

export default References;
