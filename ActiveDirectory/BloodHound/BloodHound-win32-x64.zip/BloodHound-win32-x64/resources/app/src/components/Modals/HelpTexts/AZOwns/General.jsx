import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `Object ownership means almost all abuses are possible against the target object.`;
    return { __html: text };
};

export default General;
