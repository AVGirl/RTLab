const Opsec = () => {
    let text = `There are no opsec considerations related to this edge.`;
    return { __html: text };
};

export default Opsec;
