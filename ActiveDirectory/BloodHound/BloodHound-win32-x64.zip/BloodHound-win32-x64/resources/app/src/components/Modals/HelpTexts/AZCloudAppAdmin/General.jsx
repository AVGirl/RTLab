import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `Principals with the Cloud App Admin role can control tenant-resident apps`;
    return { __html: text };
};

export default General;
