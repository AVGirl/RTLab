const Opsec = () => {
    let text = `The Azure Activity Log will log who activated an admin role for what other principal, including the date and time.`;
    return { __html: text };
};

export default Opsec;