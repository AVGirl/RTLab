const References = () => {
    let text = `<a href="https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadrole">https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadrole </a>`;
    return { __html: text };
};

export default References;
