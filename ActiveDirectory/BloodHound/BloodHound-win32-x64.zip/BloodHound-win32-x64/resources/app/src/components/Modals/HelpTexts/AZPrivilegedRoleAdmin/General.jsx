import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The Privileged Role Admin role can grant any other admin role to another principal at the tenant level.`;
    return { __html: text };
};

export default General;