import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The ability to add other principals to an Azure security group`;
    return { __html: text };
};

export default General;
