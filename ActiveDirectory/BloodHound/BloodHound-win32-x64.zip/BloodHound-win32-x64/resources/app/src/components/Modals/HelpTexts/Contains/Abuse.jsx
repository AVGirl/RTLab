import { typeFormat } from '../Formatter';
const Abuse = (sourceName, sourceType, targetName, targetType) => {
    let text = `There is no abuse info related to this edge.`;
    return { __html: text };
};

export default Abuse;
