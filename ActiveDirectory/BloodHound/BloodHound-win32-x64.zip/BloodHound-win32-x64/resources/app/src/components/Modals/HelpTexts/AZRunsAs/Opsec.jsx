const Opsec = () => {
    let text = `No opsec considerations for this edge.`;
    return { __html: text };
};

export default Opsec;