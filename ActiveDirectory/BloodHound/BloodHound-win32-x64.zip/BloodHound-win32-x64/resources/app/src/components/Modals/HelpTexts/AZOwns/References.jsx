const References = () => {
    let text = `<a href="https://blog.netspi.com/attacking-azure-with-custom-script-extensions/">https://blog.netspi.com/attacking-azure-with-custom-script-extensions/</a>`;
    return { __html: text };
};

export default References;
