const Opsec = () => {
    let text = `The Azure portal will create a log even whenever a new credential is created for a service principal.`;
    return { __html: text };
};

export default Opsec;
